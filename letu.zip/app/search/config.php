<?php
defined('IN_TS') or die('Access Denied.');

require_once THINKDATA."/config.inc.php";

$skin = 'default';