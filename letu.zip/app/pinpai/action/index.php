<?php

defined('IN_TS') or die('Access Denied.');

	$title = '品牌专区';
	include template("index");