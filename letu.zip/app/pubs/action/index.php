<?php 
defined('IN_TS') or die('Access Denied.');
header("Location: ".SITE_URL."index.php");