<?php 

$titel = '配置';
include template("admin/options");