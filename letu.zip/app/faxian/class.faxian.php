<?php
defined('IN_TS') or die('Access Denied.');  
class faxian{

	var $db;

	function faxian($dbhandle){
		$this->db = $dbhandle;
	}

}
