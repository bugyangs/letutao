<?php
defined('IN_TS') or die('Access Denied.');
return array (
  'name' => '消息盒子',
  'version' => '1.0',
  'desc' => 'ImBox消息盒子',
  'url' => 'http://www.tuntron.com',
  'email' => '70020765@qq.com',
  'author' => 'Letu',
  'author_url' => 'http://www.tuntron.com',
  'isoption' => '0',
  'isinstall' => '1',
  'issql' => '1',
  'issystem' => '1',
  'isappnav'	=> '0',
);
?>