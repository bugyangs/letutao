<?php
defined('IN_TS') or die('Access Denied.');
return array(
	'name'	=> '关于',
	'version'	=> '1.0',
	'desc'	=> '关于APP',
	'url' => 'http://www.tuntron.com',
	'email' => '70020765@qq.com',
	'author' => '橙子',
	'author_url' => 'http://www.tuntron.com',
	'isoption'	=> '1',
	'isinstall'	=> '1',
	'issql' => '1',
	'issystem'	=> '1',
	'isappnav'	=> '1',
);