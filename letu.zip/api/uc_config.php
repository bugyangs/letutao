<?php
	define('UC_CONNECT', '');  //链接方式，请保留为空
	define('UC_DBHOST', 'localhost'); //uc数据库地址，默认为loaclhost
	define('UC_DBUSER', 'root');  //UC数据库账号
	define('UC_DBPW', 'root');  //UC数据库密码
	define('UC_DBNAME', 'tuntron'); //UC数据库名
	define('UC_DBCHARSET', 'utf8');//uc编码
	define('UC_DBTABLEPRE', '`uc_');//UC表前缀
	define('UC_DBCONNECT', '0');
	define('UC_KEY', '123456');//与UC通讯的密匙
	define('UC_API', 'http://bbs.tuntron.com/uc_server'); //UC访问地址
	define('UC_CHARSET', 'utf8'); //编码
	define('UC_IP', '');//保留为空
	define('UC_APPID', '3');//在UC中与乐兔淘通讯的APPID
	define('UC_PPP', '20'); //默认不变




