<?php
/*
 * 登录入口
 */
	header("Location: ../index.php?app=system&ac=login");
	exit;