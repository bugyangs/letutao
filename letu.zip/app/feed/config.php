<?php
defined('IN_TS') or die('Access Denied.');
	/*
	 *包含数据库配置文件
	 */
	require_once THINKDATA."/config.inc.php";
	
	$TS_APP['options']['appname'] = '动态';
	
	$skin = 'default';