<?php
defined('IN_TS') or die('Access Denied.');
return array (
  'name' => '采集器',
  'version' => '1.0',
  'desc' => '采集各种数据',
  'url' => 'http://www.letutao.com',
  'email' => '70020765@qq.com',
  'author' => '橙子',
  'author_url' => 'http://www.letutao.com',
  'isoption' => '1',
  'isinstall' => '1',
  'issql' => '1',
  'issystem' => '1',
  'isappnav'	=> '1',
);
?>