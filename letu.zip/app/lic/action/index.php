<?php
	defined('IN_TS') or die('Access Denied.');
	header("Location: index.php?app=lic&ac=lication");
	exit;